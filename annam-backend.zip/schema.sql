CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS ngos (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  address TEXT,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Donor','NGO','Volunteer')),
  ngo_id TEXT REFERENCES ngos(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK ((role = 'NGO' AND ngo_id IS NOT NULL) OR (role <> 'NGO' AND ngo_id IS NULL))
);

CREATE TABLE IF NOT EXISTS donations (
  id BIGSERIAL PRIMARY KEY,
  donor_id UUID NOT NULL REFERENCES users(id),
  food_type TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  expires_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'POSTED'
    CHECK (status IN ('POSTED','ACCEPTED','IN_TRANSIT','DELIVERED','EXPIRED')),
  ngo_id TEXT REFERENCES ngos(id),
  volunteer_id UUID REFERENCES users(id),
  verification_pin_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  accepted_at TIMESTAMPTZ,
  picked_up_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS donations_status_expiry_idx ON donations(status, expires_at);
CREATE INDEX IF NOT EXISTS donations_donor_idx ON donations(donor_id);
CREATE INDEX IF NOT EXISTS donations_ngo_idx ON donations(ngo_id);
CREATE INDEX IF NOT EXISTS donations_volunteer_idx ON donations(volunteer_id);
