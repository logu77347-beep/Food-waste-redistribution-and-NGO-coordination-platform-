require('dotenv').config();
const fs = require('fs');
const path = require('path');
const db = require('../db');

(async () => {
  try {
    const sql = fs.readFileSync(path.join(__dirname, '../../schema.sql'), 'utf8');
    await db.query(sql);
    console.log('Database schema created.');
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  } finally {
    await db.pool.end();
  }
})();
