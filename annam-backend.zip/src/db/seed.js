require('dotenv').config();
const db = require('../db');

const ngos = [
  ['N1','Anbu Illam',13.0827,80.2707,'Chennai, Tamil Nadu',true],
  ['N2','Asha Community Kitchen',13.0674,80.2376,'Chennai, Tamil Nadu',true],
  ['N3','Thulir Trust',12.9941,80.2185,'Chennai, Tamil Nadu',true],
  ['N4','Kaval Food Bank',13.1143,80.2329,'Chennai, Tamil Nadu',true]
];

(async () => {
  try {
    for (const ngo of ngos) {
      await db.query(
        `INSERT INTO ngos(id,name,latitude,longitude,address,verified)
         VALUES($1,$2,$3,$4,$5,$6)
         ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,latitude=EXCLUDED.latitude,
         longitude=EXCLUDED.longitude,address=EXCLUDED.address,verified=EXCLUDED.verified`,
        ngo
      );
    }
    console.log('Demo NGO records inserted.');
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  } finally {
    await db.pool.end();
  }
})();
