const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { asyncHandler } = require('../utils');
const { requireAuth } = require('../middleware/auth');

router.post('/register', asyncHandler(async (req, res) => {
  const { name, email, password, role, ngoId } = req.body || {};
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'Name, email, password and role are required.' });
  }
  if (!['Donor', 'NGO', 'Volunteer'].includes(role)) {
    return res.status(400).json({ error: 'Role must be Donor, NGO or Volunteer.' });
  }
  if (String(password).length < 8) {
    return res.status(400).json({ error: 'Password must contain at least 8 characters.' });
  }
  if (role === 'NGO' && !ngoId) {
    return res.status(400).json({ error: 'Choose an NGO organisation.' });
  }
  if (role !== 'NGO' && ngoId) {
    return res.status(400).json({ error: 'Only NGO accounts can be linked to an organisation.' });
  }
  if (role === 'NGO') {
    const ngo = await db.query('SELECT id FROM ngos WHERE id=$1 AND verified=TRUE', [ngoId]);
    if (!ngo.rowCount) return res.status(400).json({ error: 'This NGO is not verified or does not exist.' });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  try {
    const result = await db.query(
      `INSERT INTO users(name,email,password_hash,role,ngo_id)
       VALUES($1,LOWER($2),$3,$4,$5)
       RETURNING id,name,email,role,ngo_id,created_at`,
      [String(name).trim(), String(email).trim(), passwordHash, role, role === 'NGO' ? ngoId : null]
    );
    const user = result.rows[0];
    const token = signToken(user);
    res.status(201).json({ user, token });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Email is already registered.' });
    throw err;
  }
}));

router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
  const result = await db.query(
    `SELECT id,name,email,role,ngo_id,password_hash FROM users WHERE email=LOWER($1)`,
    [String(email).trim()]
  );
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  delete user.password_hash;
  res.json({ user, token: signToken(user) });
}));

router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const result = await db.query(
    'SELECT id,name,email,role,ngo_id,created_at FROM users WHERE id=$1',
    [req.user.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Account not found.' });
  res.json({ user: result.rows[0] });
}));

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, ngoId: user.ngo_id || null },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );
}

module.exports = router;
