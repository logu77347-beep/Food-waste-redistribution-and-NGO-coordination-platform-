const router = require('express').Router();
const db = require('../db');
const { asyncHandler, haversineKm } = require('../utils');

router.get('/', asyncHandler(async (req, res) => {
  const result = await db.query(
    'SELECT id,name,latitude,longitude,address,verified FROM ngos WHERE verified=TRUE ORDER BY name'
  );
  res.json({ ngos: result.rows });
}));

router.get('/nearby', asyncHandler(async (req, res) => {
  const lat = Number(req.query.lat), lon = Number(req.query.lon);
  const radius = Math.min(Number(req.query.radiusKm || process.env.MATCH_RADIUS_KM || 10), 100);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return res.status(400).json({ error: 'Valid lat and lon query parameters are required.' });
  }
  const result = await db.query(
    'SELECT id,name,latitude,longitude,address FROM ngos WHERE verified=TRUE'
  );
  const ngos = result.rows.map(n => ({
    ...n, distanceKm: Number(haversineKm(lat, lon, n.latitude, n.longitude).toFixed(2))
  })).filter(n => n.distanceKm <= radius).sort((a,b) => a.distanceKm - b.distanceKm);
  res.json({ radiusKm: radius, ngos });
}));

module.exports = router;
