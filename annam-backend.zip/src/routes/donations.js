const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAuth, allowRoles } = require('../middleware/auth');
const { asyncHandler, haversineKm, makePin } = require('../utils');

router.use(requireAuth);

router.get('/', asyncHandler(async (req, res) => {
  await expireOldDonations();
  const { status, lat, lon, radiusKm } = req.query;
  const params = [];
  let where = [];
  if (status) {
    const allowed = ['POSTED','ACCEPTED','IN_TRANSIT','DELIVERED','EXPIRED'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status filter.' });
    params.push(status); where.push(`d.status=$${params.length}`);
  }
  if (req.user.role === 'Donor') {
    params.push(req.user.id); where.push(`d.donor_id=$${params.length}`);
  } else if (req.user.role === 'NGO') {
    params.push(req.user.ngoId);
    where.push(`(d.ngo_id=$${params.length} OR (d.status='POSTED' AND d.ngo_id IS NULL))`);
  } else if (req.user.role === 'Volunteer') {
    where.push(`(d.status='ACCEPTED' OR d.volunteer_id='${req.user.id}')`);
  }
  const sql = `
    SELECT d.id,d.food_type,d.quantity,d.latitude,d.longitude,d.expires_at,d.status,
      d.created_at,d.accepted_at,d.picked_up_at,d.delivered_at,
      donor.name AS donor_name, donor.email AS donor_email,
      n.id AS ngo_id,n.name AS ngo_name,
      v.name AS volunteer_name
    FROM donations d
    JOIN users donor ON donor.id=d.donor_id
    LEFT JOIN ngos n ON n.id=d.ngo_id
    LEFT JOIN users v ON v.id=d.volunteer_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY d.created_at DESC`;
  const result = await db.query(sql, params);
  let donations = result.rows;
  if (lat !== undefined || lon !== undefined) {
    const latitude = Number(lat), longitude = Number(lon);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      return res.status(400).json({ error: 'Provide both valid lat and lon values.' });
    }
    const radius = Math.min(Number(radiusKm || 10), 100);
    donations = donations.map(d => ({
      ...d, distanceKm: Number(haversineKm(latitude, longitude, d.latitude, d.longitude).toFixed(2))
    })).filter(d => d.distanceKm <= radius);
  }
  res.json({ donations });
}));

router.post('/', allowRoles('Donor'), asyncHandler(async (req, res) => {
  const { foodType, quantity, latitude, longitude, shelfLifeHours } = req.body || {};
  const qty = Number(quantity), lat = Number(latitude), lon = Number(longitude), hours = Number(shelfLifeHours);
  if (!foodType || String(foodType).trim().length > 120 ||
      !Number.isInteger(qty) || qty < 1 || qty > 100000 ||
      !Number.isFinite(lat) || lat < -90 || lat > 90 ||
      !Number.isFinite(lon) || lon < -180 || lon > 180 ||
      !Number.isFinite(hours) || hours <= 0 || hours > 72) {
    return res.status(400).json({ error: 'Enter a food type, positive quantity, valid coordinates and shelf life (up to 72 hours).' });
  }
  const pin = makePin();
  const pinHash = await bcrypt.hash(pin, 10);
  const result = await db.query(
    `INSERT INTO donations(donor_id,food_type,quantity,latitude,longitude,expires_at,verification_pin_hash)
     VALUES($1,$2,$3,$4,$5,NOW()+($6 * INTERVAL '1 hour'),$7)
     RETURNING id,food_type,quantity,latitude,longitude,expires_at,status,created_at`,
    [req.user.id, String(foodType).trim(), qty, lat, lon, hours, pinHash]
  );
  res.status(201).json({
    donation: result.rows[0],
    verificationPin: pin,
    message: 'Share this one-time delivery PIN securely with the receiving NGO.'
  });
}));

router.post('/:id/claim', allowRoles('NGO'), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) return res.status(400).json({ error: 'Invalid donation id.' });
  await expireOldDonations();
  // A single conditional UPDATE is atomic: only one NGO can win the reservation.
  const result = await db.query(
    `UPDATE donations SET status='ACCEPTED',ngo_id=$2,accepted_at=NOW()
     WHERE id=$1 AND status='POSTED' AND expires_at>NOW()
     RETURNING id,status,ngo_id,accepted_at`,
    [id, req.user.ngoId]
  );
  if (!result.rowCount) return res.status(409).json({ error: 'Donation is expired or has already been claimed.' });
  res.json({ donation: result.rows[0], message: 'Reservation locked for your NGO.' });
}));

router.post('/:id/pickup', allowRoles('Volunteer'), asyncHandler(async (req, res) => {
  const result = await db.query(
    `UPDATE donations SET status='IN_TRANSIT',volunteer_id=$2,picked_up_at=NOW()
     WHERE id=$1 AND status='ACCEPTED'
     RETURNING id,status,volunteer_id,picked_up_at`,
    [Number(req.params.id), req.user.id]
  );
  if (!result.rowCount) return res.status(409).json({ error: 'This donation is no longer available for pickup.' });
  res.json({ donation: result.rows[0], message: 'Pickup assigned to you.' });
}));

router.post('/:id/deliver', allowRoles('Volunteer'), asyncHandler(async (req, res) => {
  const { pin } = req.body || {};
  if (!pin || !/^\\d{6}$/.test(String(pin))) {
    return res.status(400).json({ error: 'Enter the six-digit delivery PIN.' });
  }
  const found = await db.query(
    `SELECT id,verification_pin_hash FROM donations
     WHERE id=$1 AND status='IN_TRANSIT' AND volunteer_id=$2`,
    [Number(req.params.id), req.user.id]
  );
  if (!found.rowCount) return res.status(409).json({ error: 'Only your assigned in-transit donation can be delivered.' });
  const valid = await bcrypt.compare(String(pin), found.rows[0].verification_pin_hash);
  if (!valid) return res.status(401).json({ error: 'Delivery PIN does not match.' });
  const result = await db.query(
    `UPDATE donations SET status='DELIVERED',delivered_at=NOW()
     WHERE id=$1 AND status='IN_TRANSIT' AND volunteer_id=$2
     RETURNING id,status,delivered_at`,
    [Number(req.params.id), req.user.id]
  );
  if (!result.rowCount) return res.status(409).json({ error: 'Donation status changed. Refresh and try again.' });
  res.json({ donation: result.rows[0], receipt: {
    receiptId: `ANNAM-${result.rows[0].id}`,
    deliveredAt: result.rows[0].delivered_at,
    status: 'DELIVERED'
  }});
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const result = await db.query(
    `SELECT d.id,d.food_type,d.quantity,d.latitude,d.longitude,d.expires_at,d.status,d.created_at,
      d.accepted_at,d.picked_up_at,d.delivered_at,donor.name AS donor_name,n.name AS ngo_name,
      v.name AS volunteer_name
     FROM donations d JOIN users donor ON donor.id=d.donor_id
     LEFT JOIN ngos n ON n.id=d.ngo_id LEFT JOIN users v ON v.id=d.volunteer_id
     WHERE d.id=$1`,
    [Number(req.params.id)]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Donation not found.' });
  res.json({ donation: result.rows[0] });
}));

async function expireOldDonations() {
  await db.query(
    `UPDATE donations SET status='EXPIRED'
     WHERE status='POSTED' AND expires_at<=NOW()`
  );
}

module.exports = router;
