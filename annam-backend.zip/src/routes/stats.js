const router = require('express').Router();
const db = require('../db');
const { asyncHandler } = require('../utils');

router.get('/', asyncHandler(async (_req, res) => {
  await db.query(`UPDATE donations SET status='EXPIRED'
    WHERE status='POSTED' AND expires_at<=NOW()`);
  const result = await db.query(
    `SELECT status,COUNT(*)::INT AS count FROM donations GROUP BY status`
  );
  const counts = { POSTED:0, ACCEPTED:0, IN_TRANSIT:0, DELIVERED:0, EXPIRED:0 };
  result.rows.forEach(r => { counts[r.status] = r.count; });
  res.json({ counts, total: Object.values(counts).reduce((a,b)=>a+b,0) });
}));

module.exports = router;
